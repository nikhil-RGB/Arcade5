package utilities;
//Marker interface which is to be implemented if a game
//uses MusicalArcadeGame's methods without extending the class.
public interface MusicalArcadeGameUser {

}
