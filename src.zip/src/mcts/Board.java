package mcts;

public interface Board {

}
