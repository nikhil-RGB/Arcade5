import java.io.File;

public final class Uno implements utilities.Playable{
    
	public static void main(String[] args) {
		

	}

	@Override
	public File getRules() {
		// TODO Auto-generated method stub
		return null;
	}

}
