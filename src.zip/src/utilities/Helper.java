//Marker interface to mark classes which help
//project, game management and are not games themeselves.
package utilities;
public interface Helper {
//Marker interface.
}
