//Leave for now
package new_additions;
import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
@SuppressWarnings("unused")
public class ChemicalEquationBalancer implements utilities.Playable
{
    public static void main(String[] args)
    {
    
    }
    public void create()
    {}
	@Override
	public File getRules() {
		// TODO Auto-generated method stub
		return null;
	}






}