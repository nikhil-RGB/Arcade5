package utilities;
//This marker interface must be used to mark any arcade game which 
//manages its own music & sound system.
//NOT TO BE USED FOR games which useMusicalArcadeGame instead of extending it.
//UseMusicalArcadeGameUser interface for that.
public interface AutoMusicalGame {

}
