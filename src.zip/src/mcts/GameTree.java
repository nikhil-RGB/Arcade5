package mcts;

public class GameTree {

}
