package mcts;
import java.util.*;
public class State {
Board b;
int pno;
int visits;
double winscore;
public ArrayList<State> childStates()
{return null;}//Continue from here
}
