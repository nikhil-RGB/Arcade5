package utilities;

public interface AutoRulesManager
{
public String getText();
}
